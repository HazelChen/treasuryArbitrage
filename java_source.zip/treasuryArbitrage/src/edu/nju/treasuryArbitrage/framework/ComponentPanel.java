package edu.nju.treasuryArbitrage.framework;

public interface ComponentPanel {

	public void updatePage();
}
