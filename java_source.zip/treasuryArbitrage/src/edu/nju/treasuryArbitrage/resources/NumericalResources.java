package edu.nju.treasuryArbitrage.resources;

import java.awt.Toolkit;

public class NumericalResources {

	public static final int SCREEN_WIDTH = (int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();
	public static final int SCREEN_HEIGHT = (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight();
	
}
